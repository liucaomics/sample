# https://www.rdkit.org/docs/source/rdkit.Chem.rdMolDescriptors.html#rdkit.Chem.rdMolDescriptors.GetMorganFingerprint
# https://iwatobipen.wordpress.com/2019/02/08/convert-fingerprint-to-numpy-array-and-conver-numpy-array-to-fingerprint-rdkit-memorandum/
import json
import rdkit

from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.Chem import DataStructs

import numpy as np
import pandas as pd

def createMotifSet():
	hash_motif = {}
	# amino acid
	fr = open('../../data/motif/nrp.json','r')
	hash_aa = json.load(fr)
	for key, value in hash_aa['reactants']['standardAminoAcid'].items():
		hash_motif[key] = value['SMILES']
	for key, value in hash_aa['reactants']['nonstandardAminoAcid'].items():
		hash_motif[key] = value['SMILES']
	fr.close()
	# sugar
	#fr = open('../../data/motif/saccharide.json','r')
	#hash_aa = json.load(fr)
	#for key, value in hash_aa['reactants']['standardAminoAcid'].items():
	#	hash_motif[key] = value['SMILES']
	#for key, value in hash_aa['reactants']['nonstandardAminoAcid'].items():
	#	hash_motif[key] = value['SMILES']
	#fr.close()
	fw = open('../../data/motif/motif.json','w')
	fw.write( json.dumps( hash_motif ) )

def motif2vec():
	# read motif
	fr = open('../../data/motif/motif_aa.json','r')
	hash_in = json.load(fr)
	hash_motif = {}
	for key, value in hash_in.items():
		hash_motif[key] = Chem.MolFromSmiles(value)
	fr.close()
	# output label vector
	colname = []
	for key, value in hash_motif.items():
		colname.append(key)
	df = pd.DataFrame(columns=colname)
	fr = open('../../data/library.nist.smi')
	count = 0
	for line in fr:
		row = line.strip().split()
		mol = Chem.MolFromSmiles(row[0])
		list_label = []
		for key, value in hash_motif.items():
			list_label.append( int(mol.HasSubstructMatch(value)) )
		df.loc[row[1]] = list_label
		count += 1
		print(count)
	fr.close()
	df.to_csv('../../data/motif_aa.tsv',sep='\t')

def id2Inchikey():
	hash_out = {}
	fr = open('../../data/library.nist.smi','r')
	for line in fr:
		row = line.strip().split()
		hash_out[row[1]] = row[4]
	fr.close()
	return hash_out

def inchikey2smile():
	hash_out = {}
	fr = open('../../data/library.nist.smi','r')
	for line in fr:
		row = line.strip().split()
		hash_out[row[4]] = row[0]
	fr.close()
	return hash_out

def mol2fingerprint():
	hash_id2Inchikey = id2Inchikey()
	hash_inchikey2smile = inchikey2smile()
	fr = open('../../data/library.nist.smi','r')
	fw = open('../../data/fingerprint/morgan.tsv', 'w')
	count = 0
	for line in fr:
		row = line.strip().split()
		mol = Chem.MolFromSmiles(row[0])
		fp = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=1024)
		arr = np.zeros((0,), dtype=np.int8)
		DataStructs.ConvertToNumpyArray(fp,arr)
		fw.write( '{}\t{}\n'.format(row[1],'\t'.join(arr.astype(str))) )
		print(count)
		count += 1
	fr.close()
	fw.close()

if __name__ == '__main__':
	#motif2vec()
	mol2fingerprint()






