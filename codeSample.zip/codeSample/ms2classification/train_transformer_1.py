import torch
import torch.utils.data as data
from torch.utils.tensorboard import SummaryWriter

from model import bceSumLoss, MS2Net
from data import MS2dataset

import json
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

import os

def train(model, optimizer, data_loader_train, data_loader_validation, loss_fn, num_epochs=100, logging_dir="", checkpoint_dir="./checkpoint/", device="cpu"):
	writer = SummaryWriter(logging_dir)
	plot = False
	torch.cuda.set_device(0)

	# Training loop
	for epoch in range(num_epochs):
		model.train(True)
		epoch_loss = 0.
		count_all = 0.
		count_correct = torch.zeros(1,2).to(device)
		for data_inputs, data_labels in data_loader_train:
			data_inputs = data_inputs.to(device)
			data_labels = data_labels.to(device)
			print("data:", data_inputs.device, data_labels.device)

			#if not plot:
			#	writer.add_graph(model, data_inputs.to('cpu'))
			#	plot = True
			#	data_inputs.to(device)

			preds = model(data_inputs)
			#print( preds.get_device() )
			print("pred:", data_inputs.device, data_labels.device, preds.device)

			count_all += preds.shape[0]
			count_correct += ((preds>0.5) == data_labels).sum(axis=0)

			loss = loss_fn(preds, data_labels.float())
			optimizer.zero_grad()
			loss.backward()
			optimizer.step()
			epoch_loss += loss.item()

		if epoch % 10 == 0:
			torch.save(model.state_dict(), checkpoint_dir + "model_{}.pt".format(str(epoch)) )
		
		epoch_loss /= len(data_loader_train)
		writer.add_scalar('training_loss', epoch_loss, global_step=epoch+1)
		count_correct /= count_all
		writer.add_scalar('training_acc_1', count_correct[0,0].item(), global_step=epoch+1)
		#writer.add_scalar('training_acc_2', count_correct[0,1].item(), global_step=epoch+1)
		#print("train_loss", epoch_loss, "train_accuracy_1", count_correct[0,0].item(), "train_accuracy_2", count_correct[0,1].item())
		print("train_loss", epoch_loss, "train_accuracy_1", count_correct[0,0].item())

		## validation
		model.eval()
		epoch_loss = 0.
		count_all = 0.
		count_correct = torch.zeros(1,2).to(device)
		for data_inputs, data_labels in data_loader_validation:
			data_inputs = data_inputs.to(device)
			data_labels = data_labels.to(device)

			preds = model(data_inputs)

			count_all += preds.shape[0]
			count_correct += ( (preds>0.5)==data_labels ).sum(axis=0)

			loss = loss_fn(preds, data_labels.float())
			epoch_loss += loss.item()

		epoch_loss /= len(data_loader_validation)
		writer.add_scalar('validation_loss', epoch_loss, global_step=epoch+1)
		count_correct /= count_all
		writer.add_scalar('validation_acc_1', count_correct[0,0].item(), global_step=epoch+1)
		#writer.add_scalar('validation_acc_2', count_correct[0,1].item(), global_step=epoch+1)
		#print("val_loss", epoch_loss, "val_accuracy_1", count_correct[0,0].item(), "val_accuracy_2", count_correct[0,1].item())
		#writer.add_scalar('validation_acc_2', count_correct[0,1].item(), global_step=epoch+1)
		print("val_loss", epoch_loss, "val_accuracy_1", count_correct[0,0].item())
		


if __name__ == "__main__":
	experiment = "1"
	if not os.path.exists( 'checkpoint_{}'.format(experiment) ):
		os.makedirs( 'checkpoint_{}'.format(experiment) )
	config = {
		"path_MS2" : "/projects/mohimanilab/liu/paper/MS2classification/data/filtered_nist.mgf",
    	"path_label" : "/projects/mohimanilab/liu/paper/MS2classification/data/motif_aa.tsv",
		"seq_length":20,
		"in_dim":2,
		"list_emb_dims":[12,12],
		"n_heads":3, 
		"list_mlp_dim":[20,20],
		"out_mlp_dim":[20,10],
		"n_tasks":1,
		"lr":0.1,
		"n_epochs" : 1000,
		"checkpoint_dir": "./checkpoint_{}/".format(experiment),
		"logging_dir" : "",
		"device" : "cuda",
		"batch_size":128
	}
	with open('config_{}.json'.format(experiment), 'w') as outfile:
		json.dump(config, outfile)

	dataset = MS2dataset(config["path_MS2"], config["path_label"])
	model = MS2Net(config["seq_length"], config["in_dim"], config["list_emb_dims"], config["n_heads"], config["list_mlp_dim"], config["out_mlp_dim"], config["n_tasks"])
	model = model.to(config['device'])
	print(next(model.parameters()).device )
	optimizer = torch.optim.SGD(model.parameters(), lr=config["lr"])
	#loss_fn = bceSumLoss(weight=torch.ones(n_tasks,2)*0.5)
	loss_fn = bceSumLoss(weight=dataset.weight.to(config["device"]))
	data_train, data_validation = data.random_split(dataset=dataset, lengths=[ int(len(dataset)*0.8), int(len(dataset)*0.2)+1])
	data_loader_train = data.DataLoader(data_train, batch_size=100, shuffle=True)
	data_loader_validation = data.DataLoader(data_validation, batch_size=100, shuffle=True)
	print("#### start training:")
	train(model, optimizer, data_loader_train, data_loader_validation, loss_fn, config["n_epochs"], config["logging_dir"], config["checkpoint_dir"],config["device"])





