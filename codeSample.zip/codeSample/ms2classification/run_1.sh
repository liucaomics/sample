#!/bin/bash
#SBATCH -p moh2-gpu
#SBATCH --mem=30G
#SBATCH -N 1
#SBATCH -c 1
#SBATCH --gres gpu:1
#SBATCH -t 01-00:00:00
#SBATCH -o ./slurm/train.sh_%j.out
#SBATCH -e ./slurm/train.sh_%j.err

tic=`date "+%Y-%m-%d %H:%M:%S"`;
printf "start at $tic\n\n";

python train_transformer_1.py;

toc=`date "+%Y-%m-%d %H:%M:%S"`;
printf "finish at $toc\n\n";

