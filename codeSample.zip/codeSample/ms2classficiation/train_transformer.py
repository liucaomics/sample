import torch
from model import bceSumLoss, MS2Net
from data import MS2dataset
from torch.utils.tensorboard import SummaryWriter

def train(model, optimizer, data_loader_train, data_loader_validation, loss_fn, num_epochs=100, logging_dir="", checkpoint_dir="./checkpoint/",device="GPU"):
	writer = SummaryWriter(logging_dir)
	plot = False

	# Training loop
	for epoch in range(num_epochs):
		model.train(True)
		epoch_loss = 0.
		for data_input, data_labels in data_loader_train:
			data_inputs = data_input.to(device)
			data_labels = data_labels.to(device)

			if not plot:
				writer.add_graph(model, data_inputs)
				plot = True

			preds = model(data_input)
			loss = loss_fn(preds, data_labels.float())
			optimizer.zero_grad()
			loss.backward()
			optimizer.step()
			epoch_loss += loss.item()

		if epoch % 10 == 0:
			torch.save(model.state_dict(), checkpoint_dir + "model_{}.pt".format(str(epoch)) )

		epoch_loss /= len(data_labels)
		writer.add_scaler('training_loss', epoch_loss, global_step=epoch+1)

		## validation
		model.train(False)
		epoch_loss = 0.
		for data_input, data_labels in data_loader_validation:
			data_inputs = data_input.to(device)
			data_labels = data_labels.to(device)

			preds = model(data_input)
			loss = loss_fn(preds, data_labels.float())
			epoch_loss += loss.item()

		epoch_loss /= len(data_labels)
		writer.add_scaler('validation_loss', epoch_loss, global_step=epoch+1)

if __name__ == "__main__":
	config = {
		"path_MS2" : "filtered_nist.mgf"
    	"path_label" : "library.nist.smi"
		"seq_length":20,
		"in_dim":2,
		"list_emb_dims":[12,12,12],
		"n_heads":4, 
		"list_mlp_dim":[20,20,20],
		"out_mlp_dim":[20,10],
		"n_tasks":54,
		"lr":0.01,
		"n_epochs" : 500,
		"checkpoint_dir": "./checkpoint/",
		"logging_dir" : "",
		"device" : "GPU",
		"batch_size":100
	}
	dataset = MS2dataset(config["path_MS2"], config["path_label"])
	model = MS2Net(config["seq_length"], config["in_dim"], config["list_emb_dims"], config["n_heads"], config["list_mlp_dims"], config["out_mlp_dim"], config["n_task"])
	optimizer = torch.optim.Adam(model.parameters(), lr=config["lr"])
	loss_fn = bceSumLoss(weight=torch.ones(n_tasks,2)*0.5)
	
	data_train, data_validation = data.random_split([ int(len(dataset)*0.8), int(len(dataset)*0.2)])
	data_loader_train = data.DataLoader(data_train, batch_size=100, shuffle=True)
	data_loader_validation = data.DataLoader(data_validation, batch_size=100, shuffle=True)
	
	train(model, optimizer, data_loader_train, data_loader_validation, loss_fn, config["n_epochs"], config["logging_dir"], config["checkpoint_dir"],device="GPU")





