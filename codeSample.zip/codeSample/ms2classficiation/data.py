import rdkit
from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.Chem import DataStructs

import pandas as pd
import numpy as np

import torch
import torch.utils.data as data

class MS2dataset(data.Dataset):
    def __init__(self, path_MS2, path_label, threshold=0, resolution=0.1, mz_upper=2000):
        super().__init__()
        self.threshold = threshold
        self.resolution = resolution
        self.mz_upper = mz_upper
        hash_ms2 = self._read_mgf(path_MS2, threshold)
        hash_label = self._read_label(path_label)
        self.ms2 = {}
        self.label = {}
        count = 0
        for key, value in hash_ms2.items():
            self.ms2[count] = value
            self.label[count] = hash_label[key]
            count += 1

    def __len__(self):
        return len(self.label)

    def __getitem__(self,idx):
        #return MS2dataset.sparse2dense(self.ms2[idx], self.resolution, self.mz_upper), MS2dataset.smiles2fingerprint(self.label[idx])
        return MS2dataset.sparseTopPeaks(self.ms2[idx]), MS2dataset.smiles2fingerprint(self.label[idx])
        
    def _read_mgf(self, path_MS2, threshold):
        hash_ms2 = {}
        fr = open(path_MS2, 'r')
        count = 0
        for line in fr:
            if line[:3] == 'BEG':
                line = fr.readline()
                spectrum_id = ''
                mass = 0
                charge = 0
                peaks = []
                # iterative meta data
                while '=' in line:
                    if line[:5] == 'SPECT':
                        spectrum_id = line.strip().split('=')[1]
                    elif line[:3] == 'PEP':
                        row = line.strip().split('=')
                        mass = float( row[1].split()[0] )
                    elif line[:6] == "CHARGE":
                        charge = int(line.strip().split('=')[1][0])
                    line = fr.readline()
                # iterate peaks
                while line[:3]!='END':
                    row = [float(i) for i in line.strip().split()]
                    if row[1]>threshold:
                        peaks.append([row[0],row[1]])
                    line = fr.readline()
                hash_ms2[spectrum_id] = peaks
                #print(count)
                #count += 1
        fr.close()
        return hash_ms2

    def _read_label(self,path_label):
        hash_out = {}
        fr = open(path_label, 'r')
        for line in fr:
            row = line.strip().split()
            hash_out[row[1]] = row[0]
        fr.close()
        return hash_out

    @staticmethod
    def smiles2fingerprint(smiles):
        mol = Chem.MolFromSmiles(smiles)
        fp = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=1024)
        arr = np.zeros((0,))
        DataStructs.ConvertToNumpyArray(fp,arr)
        return torch.tensor(arr)

    @staticmethod
    def sparse2dense(list_ms2, resolution, mz_upper):
        out = torch.zeros( int(mz_upper/resolution) )
        for mz in list_ms2:
            index = int(mz/resolution)
            out[index] = 1.
        return out

    @staticmethod
    def sparseTopPeaks(peaks,k=20):
        a = sorted(peaks, key=lambda x: x[1], reverse=True)
        if len(peaks>=20):
            return a[:20]
        else:
            return a + [[0.,0.]]*(20-len(peaks))

if __name__ == "__main__":
    path_MS2 = "/Users/cello/project/cmu/MS2classifier/data/filtered_nist.mgf"
    path_label = "/Users/cello/project/cmu/MS2classifier/data/library.nist.smi"
    dataset = MS2dataset(path_MS2, path_label)
    print( len(dataset) )
    print( dataset[10] )









