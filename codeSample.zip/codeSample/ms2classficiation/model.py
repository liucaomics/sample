import torch
import torch.nn as nn
import torch.nn.functional as F

class multiheadAttentionBlock(nn.Module):
	def __init__(self, in_dim, emb_dim, n_heads): 
		super().__init__()
		self.embed_dim = emb_dim
		self.n_heads = n_heads
		self.head_dim = self.embed_dim // n_heads
		# query, key, and value transformation
		self.Qtransform = nn.Linear(in_dim, emb_dim)
		self.Ktransform = nn.Linear(in_dim, emb_dim)
		self.Vtransform = nn.Linear(in_dim, emb_dim)
		# output layer
		self.out = nn.Linear(emb_dim, emb_dim)

	def forward(self, x):
		B, L, in_dim = x.size()
		# query, key, value: (B, L, self.n_heads, self.head_dim)
		query = self.Qtransform(x).reshape(B, L, self.n_heads, self.head_dim)
		key = self.Ktransform(x).reshape(B, L, self.n_heads, self.head_dim)
		value = self.Vtransform(x).reshape(B, L, self.n_heads, self.head_dim)
		# swap dimension into (B, n_heads, L, head_dim)
		query = query.permute(0,2,1,3)
		key = key.permute(0,2,1,3)
		value = value.permute(0,2,1,3)
		# compute attention and value:
		values, att = multiheadAttentionBlock.scaledDotProduct(query, key, value)
		values = values.permute(0,2,1,3).reshape(B, L, self.embed_dim)
		return self.out(values), att

	@staticmethod
	def scaledDotProduct(query, key, value):
		'''
		query: (B, H, L, D)
		key: (B, H, L, D)
		value: (B, H, L, D)
		B: batch size
		H: number of heads
		L: length of the sequence
		D: dimension of the head dimention
		'''
		D = torch.tensor( query.size()[-1] )
		# att: (B, H, L, L)
		att = query @ key.transpose(-2,-1) / torch.sqrt(D)
		att = F.softmax(att,dim=-1)
		# v: (B, H, L, D)
		v = att @ value
		return v, att

class encoder(nn.Module):
	def __init__(self, in_dim, emb_dim, n_heads, mlp_dim, dropout=0.2):
		super().__init__()
		self.att = multiheadAttentionBlock(in_dim, emb_dim, n_heads)
		self.mlp = nn.Sequential( 
			nn.Linear(emb_dim, mlp_dim),
			nn.ReLU(inplace=True),
			nn.Linear(mlp_dim, emb_dim)
		)
		self.normalize1 = nn.LayerNorm(emb_dim)
		self.normalize2 = nn.LayerNorm(emb_dim)
		self.dropout = nn.Dropout(dropout)

	def forward(self,x):
		x = x + self.att(x)
		x = self.normalize1(x)
		x = x + self.mlp(x)
		x = self.normalize2(x)
		x = self.dropout(x)
		return x

class MS2Net(nn.Module):
	def __init__(self, seq_length, in_dim, list_emb_dims, n_heads, list_mlp_dims, out_mlp_dim, n_task):
		super.__init__()
		self.linear_in = nn.Linear(in_dim, list_emb_dims[0])
		self.encoders = nn.Sequential()
		self.encoders.append( encoder(in_dim, list_emb_dims[0], n_heads, list_mlp_dims[0]) )
		for i in range(len(list_emb_dims)):
			self.encoders.append(encoder(list_emb_dims[i], list_emb_dims[i]), n_heads, list_mlp_dims[i])
		self.mlp_out = nn.Sequential()
		self.mlp_out.append( nn.Linear(list_emb_dims[-1], out_dim[0]) )
		d_last = out_mlp_dim[0]
		for d in out_dim[1:]:
			self.mlp_out.append( nn.ReLU(inplace=True) )
			self.mlp_out.append( nn.Linear(d_last, d) )
			d_last = d
		self.last = nn.Linear( out_mlp_dim[-1]*,n_task)

	def forward(self, x):
		x = self.linear_in(x)
		x = self.encoders(x)
		x = self.mlp_out(x)
		B, L, D = x.size()
		x = x.reshape(B,L*D)
		x = self.last(x)
		x = nn.Sigmoid(x)
		return x

class bceSumLoss(nn.Module):
	def __init__(self, weight):
		'''
		loss function for fingerprint. Weighted by the class proportion of each class
		weight: a (k, ) tensor
		'''
		super().__init__()
		self.weight = weight

	def forward(self, x, y):
		'''
		x: a (N, k) tensor with values in (0,1)
		y: a (N, k) tensor binary
		N: batch size
		k: number of tasks
		'''
		l = -(y*torch.log(x)*(1-self.weight) + (1-y)*torch.log(1-x)*self.weight)
		return l.mean()

if __name__ == '__main__':
	x = torch.randn(6, 8, 2)
	a = multiheadAttentionBlock(2, 10, 5)

