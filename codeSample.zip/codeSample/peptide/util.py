import rdkit
from rdkit import Chem 
from rdkit.Chem.Draw import rdMolDraw2D
from rdkit.Chem.rdFMCS import FindMCS
from rdkit.Chem.rdMolDescriptors import CalcMolFormula

import numpy as np
import scipy
import seaborn
import json
import networkx as nx
import matplotlib.pyplot as plt


def highlightFragments(mol_original, mol_fragmented):
	'''
	required packages: rdkit, seaborn, scipy
	mol_original: original mol object
	mol_fragmented: mol object after fragmented
	'''
	# get the fragment index for each molecule
	mat = Chem.GetAdjacencyMatrix(mol_fragmented)
	n_components, labels = scipy.sparse.csgraph.connected_components(csgraph=scipy.sparse.csr_matrix(mat), directed=False, return_labels=True)
	# prepare color palette for each fragment
	#list_colors = seaborn.color_palette(palette='pastel', n_colors=n_components, desat=None, as_cmap=True)
	list_colors = seaborn.color_palette(palette='pastel', n_colors=n_components, desat=None)
	color_palette = {}
	for i,color in enumerate(list(list_colors)):
		color_palette[i] = tuple([j for j in color]+[0.01])
	# map atom to color
	atomColors = {}
	label2atomIndex = {}
	for i, l in enumerate(labels,start=0):
		atomColors[i] = color_palette[l]
		if l in label2atomIndex:
			label2atomIndex[l].append(i)
		else:
			label2atomIndex[l] = [i]
	highlight_atoms = list(range(mol_original.GetNumAtoms()))
	# map bond to color
	bondColors = {}
	for label, value in label2atomIndex.items():
		if len(value)<2:
			continue
		else:
			for i in range(len(value)-1):
				for j in range(i,len(value),1):
					b = mol_original.GetBondBetweenAtoms(value[i],value[j])
					if b is not None:
						bondColors[b.GetIdx()] = color_palette[label]
	highlight_bonds = list(bondColors.keys())
	# prepare molecule for drawing
	mol_prepared = rdMolDraw2D.PrepareMolForDrawing(mol_original,addChiralHs=False,wedgeBonds=False,kekulize=True)
	# set drawing option
	#opt = rdMolDraw2D.MolDrawOptions()
	#opt.useBWAtomPalette()
	# setup drawer
	drawer = rdMolDraw2D.MolDraw2DSVG(1000,500)
	#drawer.SetDrawOptions(opt)
	drawer.DrawMolecule(mol_prepared,
						highlightAtoms=highlight_atoms,
						highlightAtomColors=atomColors,
						highlightBonds=highlight_bonds,
						highlightBondColors=bondColors)
	drawer.FinishDrawing()
	svg = drawer.GetDrawingText()
	#.replace('svg:','')
	return svg

def mol_with_atom_index( mol ):
    atoms = mol.GetNumAtoms()
    for idx in range( atoms ):
        mol.GetAtomWithIdx( idx ).SetProp( 'molAtomMapNumber', str( mol.GetAtomWithIdx( idx ).GetIdx() ) )
    return mol

def fasta2nx(fasta):
	hash_aa = {'A':'ala','R':'arg','N':'asn','D':'asp','C':'cys','Q':'gln','E':'glu','G':'gly','H':'his','I':'ile','L':'leu','K':'lys','M':'met','F':'phe','P':'pro','S':'ser','T':'thr','W':'trp','Y':'tyr','V':'val'}
	list_nodes = []
	count = 0
	for aa in fasta[:-1]:
		list_nodes.append( (count,{'label':hash_aa[aa]}) )
		count += 1
	list_nodes.append( (count,{'label':hash_aa[fasta[-1]]+'_Cter'}) )
	list_edges = []
	for i in range(len(fasta)-1):
		list_edges.append( (i,i+1) )
	G = nx.Graph()
	G.add_nodes_from(list_nodes)
	G.add_edges_from(list_edges)
	return G

def MCS_similarity(smi1, smi2):
	mol1 = Chem.MolFromSmiles(smi1)
	mol2 = Chem.MolFromSmiles(smi2)
	MCS_result = FindMCS([mol1,mol2])
	intersection = float(MCS_result.numAtoms + MCS_result.numBonds)
	union = mol1.GetNumAtoms() + mol1.GetNumBonds() + mol2.GetNumAtoms() + mol2.GetNumBonds() - intersection
	return intersection / union




