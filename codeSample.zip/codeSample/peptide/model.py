import dgl
import torch
import torch.nn as nn
from dgl.nn.pytorch import GraphConv
import torch.nn.functional as F
import dgl.function as fn

####### linear policy ##########
class linearEdgeAction(nn.Module):
	def __init__(self, in_feats, out_feats):
		super(linearEdgeAction, self).__init__()
		self.linear = nn.Linear(in_feats, out_feats)

	def forward(self, g):
		src, dst = g.edges(form='uv')
		a = g.ndata['x'][src]
		b = g.ndata['x'][dst]
		feature = torch.cat( [g.edata['x'],a, b], 1 )
		h = self.linear(feature)
		return torch.squeeze(h)

class linearTerminationAction(nn.Module):
	def __init__(self, in_feats, out_feats):
		super(linearTerminationAction, self).__init__()
		self.linear = nn.Linear(in_feats, out_feats)
		self.sigmoid = nn.Sigmoid()

	def forward(self,g):
		 x = torch.mean(g.edata['x'],axis=0)
		 x = self.linear(x)
		 return self.sigmoid(x)

class linearAction(nn.Module):
	def __init__(self, in_feats, out_feats):
		super(linearAction, self).__init__()
		self.linear = nn.Linear(in_feats, out_feats)

	def forward(self, g):
		src, dst = g.edges(form='uv')
		a = g.ndata['x'][src]
		b = g.ndata['x'][dst]
		feature_1 = torch.cat( [torch.ones( (a.shape[0],1),dtype=torch.float64),g.edata['x'],a, b], 1 )
		feature_0 = torch.cat( [torch.zeros( (a.shape[0],1),dtype=torch.float64),g.edata['x'],a, b], 1 )
		feature = torch.cat([feature_0,feature_1],0)
		h = self.linear(feature)
		return torch.squeeze(h)

class gnnEdgeAction(nn.Module):
	def __init__(self, in_dim, hidden_dim, out_dim):
		super(gnnEdgeAction, self).__init__()
		self.conv1 = myConv(in_dim, hidden_dim)
		self.conv2 = myConv(hidden_dim, hidden_dim)
		self.linear = nn.Linear(in_dim*3, out_dim)
		self.linear.bias.data.fill_(10)

	def forward(self, g):
		h = self.conv1(g,g.ndata['x'])
		h = self.conv2(g,h)
		g.edata['feature'] = torch.zeros(len(g.edges),4*3,dtype=torch.float64)
		for u, v, eid in zip(*g.edges(form='all')):
			g.edata['feature'][eid] = torch.cat( [g.edata['x'][eid],h[u],h[v]] )
		out = self.linear(g.edata['feature'])
		return torch.squeeze(out)


class gnnTerminationAction(nn.Module):
	def __init__(self, in_dim, hidden_dim, out_dim):
		super(gnnTerminationAction, self).__init__()
		self.conv1 = myConv(in_dim, hidden_dim)
		self.conv2 = myConv(hidden_dim, hidden_dim)
		self.linear = nn.Linear(in_dim, out_dim)
		self.linear.bias.data.fill_(10)
		self.sigmoid = nn.Sigmoid()

	def forward(self,g):
		h = self.conv1(g,g.ndata['x'])
		h = self.conv2(g,h)
		h = self.linear(h)
		g.ndata['h'] = h
		hg = dgl.max_nodes(g,'h')
		return torch.squeeze( self.sigmoid(hg) )

class gnnAction(nn.Module):
	def __init__(self, in_dim, hidden_dim, out_dim):
		super(gnnAction, self).__init__()
		self.conv1 = myConv(in_dim, hidden_dim)
		self.conv2 = myConv(hidden_dim, hidden_dim)
		self.linear = nn.Linear(in_dim*3, out_dim)
		self.linear.bias.data.fill_(10)

	def forward(self, g):
		h = self.conv1(g,g.ndata['x'])
		h = self.conv2(g,h)
		g.edata['feature'] = torch.zeros(len(g.edges),4*3,dtype=torch.float64)
		for u, v, eid in zip(*g.edges(form='all')):
			g.edata['feature'][eid] = torch.cat( [g.edata['x'][eid],h[u],h[v]] )
		out = self.linear(g.edata['feature'])
		return torch.squeeze(out)


class myConv(nn.Module):
	def __init__(self,in_dim,out_dim):
		super(myConv, self).__init__()
		self.linear = nn.Linear(in_dim, out_dim)
		self.linear.bias.data.fill_(10)

	def forward(self, g, features):
		with g.local_scope():
			g.ndata['h'] = features
			#g.update_all( message_func=fn.copy_u('h','m'), reduce_func=fn.mean('m','h_N') )
			#self._update_all(g)
			g.update_all(message_func=self._message_function, reduce_func=self._reduce_function)
			#h_N = g.ndata['h_N']
			#h_total = torch.cat([h,h_N], dim=1)
			return F.relu( self.linear(g.ndata['h']) )

	'''
	def _update_all(self,g):
		ratio = 0.5
		g.ndata['deg'] = g.in_degrees(g.nodes()).float()
		g.edata['msg'] = torch.zeros(len(g.edges),4)
		g.ndata['msg'] = torch.zeros(len(g.nodes),4)
		for u, v, eid in zip(*g.edges(form='all')):
			g.edata['msg'][eid] = g.ndata['h'][u] / g.ndata['deg'][v]
		for u, v, eid in zip(*g.edges(form='all')):
			g.ndata['msg'][v] += g.edata['msg'][eid]
		g.ndata['h_N'] = ratio*g.ndata['h']+(1-ratio)*g.ndata['msg']
	'''

	def _message_function(self, edges):
		#print(edges.src['h'].shape)
		#print(edges.dst['degree'].unsqueeze(1).shape)
		return {'h': edges.src['h']}

	def _reduce_function(self, nodes):
		r = 0.7
		return {'h':r*nodes.data['h']+(1-r)*nodes.mailbox['h'].mean(1)}




