from model import linearEdgeAction, linearTerminationAction, gnnEdgeAction, gnnTerminationAction, linearAction
import torch
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
import dgl

class motif_agent:
	def __init__(self):
		return
	def baseline_policy(self, observation):
		list_candidate = []
		for u, v, eid in zip(*observation.edges(form='all')):
			if observation.ndata['x'][u][0]==1 and observation.ndata['x'][v][2]==1:
				for pred in observation.predecessors(u):
					if observation.ndata['x'][pred][1] == 1:
						list_candidate.append([u,v])
						break
		if len(list_candidate)>0:
			index = np.random.choice(len(list_candidate))
			a = list_candidate[index]
			termination = np.random.choice(a=[0,1],size=1,replace=True,p=[0.5,0.5])
			return [termination] + a
			#return [termination] + a
		else:
			return [1,0,0]

class linearQagent:
	def __init__(self):
		self.num_edge_feature = None
		self.tau_edge = None
		self.tau_termination = None
		self.gamma = None

		self.edgeAction = None
		self.terminationAction = None

		self.last_action = None
		self.last_terminationActionPreferences = None
		self.last_edgeActionPreferences = None
		self.last_state = None

		self.episode_steps = None

		self.optimizer = None

	def agent_init(self, agent_info={}):
		self.num_edge_feature = agent_info["num_edge_feature"]
		self.tau_edge = agent_info["tau_edge"]
		self.tau_termination = agent_info["tau_termination"]
		self.gamma = agent_info["gamma"]
		self.alpha = agent_info["alpha"]

		self.episode_steps = 0 
		# action value network
		self.edgeAction = linearEdgeAction(self.num_edge_feature, 1)
		self.edgeAction.double()
		self.terminationAction = linearTerminationAction(4, 2)
		self.terminationAction.double()
		# optimizer
		self.optimizer_edgeAction = optim.Adam(self.edgeAction.parameters(), lr=0.001)
		self.optimizer_terminationAction = optim.Adam(self.terminationAction.parameters(), lr=0.001)

	def agent_policy(self, graph):
		# sample termination
		termination = 0
		if graph.number_of_edges == 0:
			termination = 1
		else:
			terminationActionPreferences = self.terminationAction(graph)
			probs_termination= F.softmax(terminationActionPreferences / self.tau_termination, dim=0)
			termination = np.random.choice(2,1,p=probs_termination.detach().numpy())
		# sample source and destination
		edgeActionPreferences = self.edgeAction(graph)
		probs_edge = F.softmax(edgeActionPreferences / self.tau_termination, dim=0).detach().numpy()
		index_edge = np.random.choice(len(probs_edge),1,p=probs_edge)
		index_src, index_dst = graph.find_edges(index_edge)
		return (np.array([termination, index_src, index_dst]), terminationActionPreferences, edgeActionPreferences)

	def agent_start(self, state):
		self.last_state = state
		#self.last_terminationActionPreferences = self.terminationAction(state)
		#self.last_edgeActionPreferences = self.edgeAction(state)
		self.last_action, self.last_terminationActionPreferences, self.last_edgeActionPreferences= self.agent_policy(state)
		return self.last_action

	def agent_step(self, reward, state):
		self.episode_steps += 1
		##### obtain new action
		new_action, terminationActionPreferences, edgeActionPreferences = self.agent_policy(state)
		# new max edge action value
		maxEdgeActionValue = torch.max(edgeActionPreferences)
		# last edge action value
		last_edge_id = self.last_state.edge_id(self.last_action[1], self.last_action[2])
		last_edgeActionValue = self.last_edgeActionPreferences[last_edge_id]
		# TD error of edge action value
		delta_edge = reward + self.gamma*maxEdgeActionValue - last_edgeActionValue
		
		# new max termination action value
		maxTerminationActionValue = torch.max(terminationActionPreferences)
		# last termination action value
		last_terminationActionValue = self.last_terminationActionPreferences[self.last_action[0]]
		# TD error of termination action value
		delta_termination = reward + self.gamma*maxTerminationActionValue - last_terminationActionValue
		
		#### update parameters ####
		# make gradient zero
		self.optimizer_terminationAction.zero_grad()
		self.optimizer_edgeAction.zero_grad()
		# get new gradient
		last_edgeActionValue.backward()
		last_terminationActionValue.backward()
		# update edge action parameters
		for para in self.edgeAction.parameters():
			para.data += self.alpha*delta_edge*para.grad.data 
		# update termination action parameters
		for para in self.terminationAction.parameters():
			para.data += self.alpha*delta_termination*para.grad.data

		## update last action, state, preferences
		self.last_action = new_action
		self.last_state = state
		self.last_edgeActionPreferences = edgeActionPreferences
		self.last_terminationActionPreferences = terminationActionPreferences
		return self.last_action

	def agent_end(self, reward):
		self.episode_steps += 1

		# last edge action value
		last_edge_id = self.last_state.edge_id(self.last_action[1], self.last_action[2])
		last_edgeActionValue = self.last_edgeActionPreferences[last_edge_id]
		# TD error of edge action value
		delta_edge = reward - last_edgeActionValue

		# last termination action value
		last_terminationActionValue = self.last_terminationActionPreferences[self.last_action[0]]
		# TD error of termination action value
		delta_termination = reward - last_terminationActionValue
		
		#### update parameters ####
		# make gradient zero
		self.optimizer_terminationAction.zero_grad()
		self.optimizer_edgeAction.zero_grad()
		# get new gradient
		last_edgeActionValue.backward()
		last_terminationActionValue.backward()
		# update edge action parameters
		for para in self.edgeAction.parameters():
			para.data += self.alpha*delta_edge*para.grad.data 
		# update termination action parameters
		for para in self.terminationAction.parameters():
			para.data += self.alpha*delta_termination*para.grad.data

class linearAllQagent:
	def __init__(self):
		self.num_edge_feature = None
		self.tau_edge = None
		self.tau_termination = None
		self.gamma = None

		self.edgeAction = None
		self.terminationAction = None

		self.last_action = None
		self.last_ActionPreferences = None
		self.last_state = None

		self.episode_steps = None

		self.optimizer = None

	def agent_init(self, agent_info={}):
		self.num_edge_feature = agent_info["num_edge_feature"]
		self.tau = agent_info["tau"]
		self.gamma = agent_info["gamma"]
		self.alpha = agent_info["alpha"]

		self.episode_steps = 0 
		# action value network
		self.linearAction = linearAction(13, 1)
		self.linearAction.double()
		# optimizer
		self.optimizer_linearAction = optim.Adam(self.linearAction.parameters(), lr=0.001)
		
	def agent_policy(self, graph):
		# sample termination
		termination = 0
		if graph.number_of_edges == 0:
			termination = 1
			linearActionPreferences = self.linearAction(graph)
			return (np.array([termination, 0, 0]), linearActionPreferences)
		else:
			linearActionPreferences = self.linearAction(graph)
			probs= F.softmax(linearActionPreferences / self.tau, dim=0)
			index_action = np.random.choice(len(probs),1,p=probs.detach().numpy())
			# sample source and destination
			if index_action >= graph.number_of_edges():
				termination = 1
				index_edge = index_action - graph.number_of_edges()
				index_src, index_dst = graph.find_edges(index_edge)
			else:
				termination = 0
				index_edge = index_action
				index_src, index_dst = graph.find_edges(index_edge)
			return (np.array([termination, index_src, index_dst]), linearActionPreferences)

	def agent_start(self, state):
		self.last_state = state
		#self.last_terminationActionPreferences = self.terminationAction(state)
		#self.last_edgeActionPreferences = self.edgeAction(state)
		self.last_action, self.last_linearActionPreferences = self.agent_policy(state)
		return (self.last_action, self.last_linearActionPreferences)

	def agent_step(self, reward, state):
		self.episode_steps += 1
		##### obtain new action
		new_action, linearActionPreferences = self.agent_policy(state)
		# new max edge action value
		maxlinearActionValue = torch.max(linearActionPreferences)
		# last edge action value
		last_edge_id = self.last_state.edge_id(self.last_action[1], self.last_action[2])
		last_action_id = last_edge_id
		if self.last_action[0] == 1:
			last_action_id += self.last_state.number_of_edges()

		last_linearActionValue = self.last_linearActionPreferences[last_action_id]
		# TD error of edge action value
		delta = reward + self.gamma*maxlinearActionValue - last_linearActionValue
		
		#### update parameters ####
		# make gradient zero
		self.optimizer_linearAction.zero_grad()
		# get new gradient
		last_linearActionValue.backward()
		# update edge action parameters
		for para in self.linearAction.parameters():
			para.data += self.alpha*delta*para.grad.data

		## update last action, state, preferences
		self.last_action = new_action
		self.last_state = state
		self.last_linearActionPreferences = linearActionPreferences
		return self.last_action

	def agent_end(self, reward):
		self.episode_steps += 1

		# last edge action value
		last_edge_id = self.last_state.edge_id(self.last_action[1], self.last_action[2])
		last_action_id = last_edge_id
		if self.last_action[0] == 1:
			last_action_id += self.last_state.number_of_edges()
		last_linearActionValue = self.last_linearActionPreferences[last_action_id]
		# TD error of edge action value
		delta = reward - last_linearActionValue
		
		#### update parameters ####
		# make gradient zero
		self.optimizer_linearAction.zero_grad()
		# get new gradient
		last_linearActionValue.backward()
		# update edge action parameters
		for para in self.linearAction.parameters():
			para.data += self.alpha*delta*para.grad.data

class gnnQagent:
	def __init__(self):
		self.num_edge_feature = None
		self.tau_edge = None
		self.tau_termination = None
		self.gamma = None

		self.edgeAction = None
		self.terminationAction = None

		self.last_action = None
		self.last_terminationActionPreferences = None
		self.last_edgeActionPreferences = None
		self.last_state = None

		self.episode_steps = None

		self.optimizer = None

	def agent_init(self, agent_info={}):
		self.num_edge_feature = agent_info["num_edge_feature"]
		self.tau_edge = agent_info["tau_edge"]
		self.tau_termination = agent_info["tau_termination"]
		self.gamma = agent_info["gamma"]
		self.alpha = agent_info["alpha"]

		self.episode_steps = 0 
		# action value network
		self.edgeAction = gnnEdgeAction(4,4,1)
		self.edgeAction.double()
		self.terminationAction = gnnTerminationAction(4,4,2)
		self.terminationAction.double()
		# optimizer
		self.optimizer_edgeAction = optim.Adam(self.edgeAction.parameters(), lr=0.0001)
		self.optimizer_terminationAction = optim.Adam(self.terminationAction.parameters(), lr=0.0001)

	def agent_policy(self, graph):
		# sample termination
		termination = 0
		if graph.number_of_edges == 0:
			termination = 1
		else:
			terminationActionPreferences = self.terminationAction(graph)
			probs_termination= F.softmax(terminationActionPreferences / self.tau_termination, dim=0)
			termination = np.random.choice(2,1,p=probs_termination.detach().numpy())
			#termination = np.argmax(probs_termination.detach().numpy())
		# sample source and destination
		edgeActionPreferences = self.edgeAction(graph)
		probs_edge = F.softmax(edgeActionPreferences / self.tau_termination, dim=0).detach().numpy()
		index_edge = np.random.choice(len(probs_edge),1,p=probs_edge)
		#index_edge = np.argmax(probs_edge)
		index_src, index_dst = graph.find_edges(index_edge)
		return (np.array([termination, index_src, index_dst]), terminationActionPreferences, edgeActionPreferences)

	def agent_start(self, state):
		self.last_state = state
		#self.last_terminationActionPreferences = self.terminationAction(state)
		#self.last_edgeActionPreferences = self.edgeAction(state)
		self.last_action, self.last_terminationActionPreferences, self.last_edgeActionPreferences= self.agent_policy(state)
		return self.last_action

	def agent_step(self, reward, state):
		self.episode_steps += 1
		##### obtain new action
		new_action, terminationActionPreferences, edgeActionPreferences = self.agent_policy(state)
		# new max edge action value
		maxEdgeActionValue = torch.max(edgeActionPreferences)
		# last edge action value
		last_edge_id = self.last_state.edge_id(self.last_action[1], self.last_action[2])
		last_edgeActionValue = self.last_edgeActionPreferences[last_edge_id]
		# TD error of edge action value
		delta_edge = reward + self.gamma*maxEdgeActionValue - last_edgeActionValue
		
		# new max termination action value
		maxTerminationActionValue = torch.max(terminationActionPreferences)
		# last termination action value
		last_terminationActionValue = self.last_terminationActionPreferences[self.last_action[0]]
		# TD error of termination action value
		delta_termination = reward + self.gamma*maxTerminationActionValue - last_terminationActionValue
		
		#### update parameters ####
		# make gradient zero
		self.optimizer_terminationAction.zero_grad()
		self.optimizer_edgeAction.zero_grad()
		# get new gradient
		last_edgeActionValue.backward()
		last_terminationActionValue.backward()
		# update edge action parameters
		for para in self.edgeAction.parameters():
			para.data += self.alpha*delta_edge*para.grad.data 
		# update termination action parameters
		for para in self.terminationAction.parameters():
			para.data += self.alpha*delta_termination*para.grad.data

		## update last action, state, preferences
		self.last_action = new_action
		self.last_state = state
		self.last_edgeActionPreferences = edgeActionPreferences
		self.last_terminationActionPreferences = terminationActionPreferences
		return self.last_action

	def agent_end(self, reward):
		self.episode_steps += 1

		# last edge action value
		last_edge_id = self.last_state.edge_id(self.last_action[1], self.last_action[2])
		last_edgeActionValue = self.last_edgeActionPreferences[last_edge_id]
		# TD error of edge action value
		delta_edge = reward - last_edgeActionValue

		# last termination action value
		last_terminationActionValue = self.last_terminationActionPreferences[self.last_action[0]]
		# TD error of termination action value
		delta_termination = reward - last_terminationActionValue
		
		#### update parameters ####
		# make gradient zero
		self.optimizer_terminationAction.zero_grad()
		self.optimizer_edgeAction.zero_grad()
		# get new gradient
		last_edgeActionValue.backward()
		last_terminationActionValue.backward()
		# update edge action parameters
		for para in self.edgeAction.parameters():
			para.data += self.alpha*delta_edge*para.grad.data 
		# update termination action parameters
		for para in self.terminationAction.parameters():
			para.data += self.alpha*delta_termination*para.grad.data





