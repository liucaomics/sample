import gym

import torch
import dgl

import rdkit
from rdkit import Chem 
from rdkit.Chem.Draw import rdMolDraw2D
from rdkit.Chem.rdFMCS import FindMCS
from rdkit.Chem.rdMolDescriptors import CalcMolFormula

import numpy as np
import scipy
import seaborn
import json
import networkx as nx
import matplotlib.pyplot as plt

from util import MCS_similarity, mol_with_atom_index, fasta2nx


class RetroEnv(gym.Env):
	metadata = {'render.modes':['human']}
	def __init__(self):
		self.original_mol = Chem.RWMol()
		self.current_mol = Chem.RWMol()
		self.atom_types = np.array(['C','O','N','S'])
		self.atomType2index = {'C':0,'O':1,'N':2,'S':3}
		self.bond_types = np.array([Chem.rdchem.BondType.SINGLE, Chem.rdchem.BondType.DOUBLE, Chem.rdchem.BondType.TRIPLE, Chem.rdchem.BondType.AROMATIC], dtype=object)
		self.bondType2index = {Chem.rdchem.BondType.SINGLE:0, Chem.rdchem.BondType.DOUBLE:1, Chem.rdchem.BondType.TRIPLE:2, Chem.rdchem.BondType.AROMATIC:3}
		self.max_num_atom = 200
		self.action_space = gym.spaces.MultiDiscrete([self.max_num_atom,self.max_num_atom,2])
		self.observation_space = {}
		self.observation_space['adj'] = gym.Space(shape=[len(self.bond_types), self.max_num_atom, self.max_num_atom])
		self.observation_space['node'] = gym.Space( shape=[1,self.max_num_atom,len(self.atom_types)] )
		self.connected_components = [0]*self.max_num_atom
		self.count = 0
		self.db_fragments = self._load_db_fragment()
		self.removed_bonds = []
		self.info = {}
		return

	def step(self,action):
		# specify done and final reward
		if action[0] == 1:
			done = True
			final_reward = self._final_reward()
			reward = final_reward
			# create connected component graph
			self._get_cc_graph()
			return self._get_observation(), reward, done, self.info
		# initialization
		observation = {}
		reward = 0
		done = False
		# take action
		bond = self.current_mol.GetBondBetweenAtoms(int(action[1]),int(action[2]))
		self.removed_bonds.append( (int(action[1]),int(action[2])) )
		self._take_action(bond)
		# specify observaion
		observation = self._get_observation()
		self.count += 1
		if len(self.current_mol.GetBonds()) == 0:
			done = True
			final_reward = self._final_reward()
			reward = final_reward
			self._get_cc_graph()

		# return 
		return observation, reward, done, self.info

	def reset(self,smiles):
		self.original_mol = mol_with_atom_index( Chem.MolFromSmiles(smiles) )
		self.current_mol = Chem.rdchem.Mol( self.original_mol )
		self.removed_bonds = []
		self.count = 0
		return self._get_observation()

	def render(self,mode='human',close=False):
		print( Chem.MolToSmiles(self.current_mol) )
		#svg = highlightFragments( self.original_mol, self.current_mol )
		#print(svg,file=open('trojactory_molecule_' + str(self.count) + '.svg','w'))

	def _take_action(self,bond):
		self.current_mol = Chem.FragmentOnBonds(self.current_mol,[bond.GetIdx()],addDummies=False)

	def _get_adjacencyMatrix(self):
		adjacency_matrix = np.zeros( (len(self.bond_types), self.max_num_atom, self.max_num_atom) )
		for bond in self.current_mol.GetBonds():
			i,j = bond.GetBeginAtomIdx(),bond.GetEndAtomIdx()
			adjacency_matrix[ self.bondType2index[bond.GetBondType()] ][i][j]=1
			adjacency_matrix[ self.bondType2index[bond.GetBondType()] ][j][i]=1
		#return Chem.GetAdjacencyMatrix( self.current_mol )
		return adjacency_matrix

	def _get_nodes(self):
		nodes = np.zeros([1,self.max_num_atom,len(self.atom_types)])
		i = 0
		for atom in self.current_mol.GetAtoms():
			nodes[0,i,self.atomType2index[atom.GetSymbol()]] = 1
			i += 1
		return nodes

	def _get_observation(self):
		#observation = {}
		#observation['adj'] = self._get_adjacencyMatrix()
		#observation['node'] = self._get_nodes()
		return self._transform_to_dgl()

	def _get_cc_graph(self):
		self.info['cc_node2label'] = {}
		G = nx.Graph()
		hash_atom2cc = {}
		list_nodes = []
		list_edges = []
		## get graph nodes 
		for key, value in self.info['cc_nodes'].items():
			list_nodes.append( (key,{'label':value['label']}) )
			#list_nodes.append( key )
			self.info['cc_node2label'][key] = value['label']
			for atom in value['atom_index']:
				hash_atom2cc[atom] = key
		## get graph edges
		for atom1, atom2 in self.removed_bonds:
			list_edges.append( (hash_atom2cc[atom1],hash_atom2cc[atom2]) )
		## create graph
		G.add_nodes_from(list_nodes)
		G.add_edges_from(list_edges)
		## save as info
		self.info['cc_graph'] = G

	def _load_db_fragment(self):
		path = "/Users/cello/Desktop/retrosynthesis/gym/gym-retro/gym_retro/data/aa.json"
		with open(path,'r') as fr:
			data = json.load(fr)
		hash_out = {}
		for aa in data['db']:
			fp =  Chem.rdmolops.RDKFingerprint( Chem.MolFromSmiles(aa['smiles']['residual']) )
			hash_out[ aa['3-letter'] ] = [aa['smiles']['residual'],fp]
			fp =  Chem.rdmolops.RDKFingerprint( Chem.MolFromSmiles(aa['smiles']['Cter']) )
			hash_out[aa['3-letter']+'_'+'Cter'] = [aa['smiles']['Cter'],fp]
		return hash_out

	def _transform_to_dgl(self):
		# create dgl graph
		G = dgl.DGLGraph()
		# set atom features
		x = []
		for atom in self.current_mol.GetAtoms():
			v_atom = [0]*self.atom_types.shape[0]
			v_atom[ self.atomType2index[atom.GetSymbol()] ] = 1.
			x.append(v_atom)
		G.add_nodes(len(x))
		G.ndata['x'] = np.array(x)
		# set edge features
		edge_attr = []		
		for bond in self.current_mol.GetBonds():
			i,j = bond.GetBeginAtomIdx(),bond.GetEndAtomIdx()
			attr = self.bondType2index[bond.GetBondType()]
			# add edges
			G.add_edges([i,j],[j,i])
			# add edge attribute
			v_attr = [0]*self.bond_types.shape[0]
			v_attr[attr] = 1.
			edge_attr.append(v_attr[:])
			edge_attr.append(v_attr[:])
		G.edata['x'] = np.array(edge_attr)
		return G


	def _final_reward(self):
		self.info['cc_nodes'] = {}
		reward = 0
		## find connected components
		frags = Chem.rdmolops.GetMolFrags(self.current_mol)
		for index, frag in enumerate(frags):
			## get smiles and fingerprint of a connected component
			smi_cc = Chem.MolFragmentToSmiles(self.current_mol,frag)
			#fp = Chem.rdmolops.RDKFingerprint( Chem.MolFromSmiles(smi_cc) )
			## search it against fragment database
			best_aa = ''
			best_score = 0
			for name, value in self.db_fragments.items():
				 #similarity = rdkit.DataStructs.FingerprintSimilarity(fp,value[1])
				 similarity = MCS_similarity(smi_cc,value[0])
				 if similarity >= best_score:
				 	best_score = similarity
				 	best_aa = name
			if best_score == 1:
				reward += best_score
			else:
				reward -= 1
			name = 'node_' + str(index)
			self.info['cc_nodes'][name] = {'best_match':best_aa,
										   'score':best_score,
										   'best_match_smiles':self.db_fragments[best_aa][0],
										   'smiles':smi_cc,
										   'atom_index':frag
											}
			if best_score == 1:
				self.info['cc_nodes'][name]['label'] = best_aa
			else:
				self.info['cc_nodes'][name]['label'] = CalcMolFormula( Chem.MolFromSmiles(smi_cc) )
		return reward


def test_RetroEnv():
	fasta = "ARNDCQE"
	G_truth = fasta2nx(fasta)
	m = Chem.rdmolfiles.MolFromFASTA(fasta)
	smiles = Chem.MolToSmiles(m)
	env = RetroEnv()
	for i_episode in range(1):
		observation = env.reset(smiles)
		for i in range(100):
			env.render()
			last_observation = dict(observation)
			a = baseline_policy(observation)
			observation,reward,done,info = env.step(a)
			if done:
				print()
				print(info)
				print( "episode {} finishes!".format(i_episode) )
				break
	
	print( nx.is_isomorphic(G_truth,env.info['cc_graph'],node_match=lambda x,y : x['label']==y['label']) )
	nx.draw(env.info['cc_graph'],with_labels=True,labels=env.info['cc_node2label'],alpha=0.5,font_size=6)
	plt.savefig("temp_cc.svg")
	svg = highlightFragments( env.original_mol, env.current_mol )
	print(svg,file=open('temp_molecule.svg','w'))
	env.close()

if __name__ == "__main__":
	fasta = "ARNDCQE"
	G_truth = fasta2nx(fasta)
	m = Chem.rdmolfiles.MolFromFASTA(fasta)
	smiles = Chem.MolToSmiles(m)
	env = RetroEnv()
	observation = env.reset(smiles)
	G = env._transform_to_dgl()
		







