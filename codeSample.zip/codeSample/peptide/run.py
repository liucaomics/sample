from npretro_env import RetroEnv
from agent import linearQagent, gnnQagent, motif_agent, linearAllQagent

import rdkit
from rdkit import Chem 
from rdkit.Chem.Draw import rdMolDraw2D
from rdkit.Chem.rdFMCS import FindMCS
from rdkit.Chem.rdMolDescriptors import CalcMolFormula

import numpy as np
import scipy
import seaborn
import json
import networkx as nx
import matplotlib.pyplot as plt

from util import fasta2nx, highlightFragments
import torch

def test_linearQagent():
	list_reward = []
	list_episode = list(range(1000))

	env = RetroEnv()
	agent_info = {"num_edge_feature":12,
				"tau_edge":0.1,
				"tau_termination":1,
				"gamma": 1.,
				"alpha":0.01
	}
	fasta = "ARN"
	G_truth = fasta2nx(fasta)
	m = Chem.rdmolfiles.MolFromFASTA(fasta)
	smiles = Chem.MolToSmiles(m)
	agent = linearQagent()
	agent.agent_init(agent_info)
	observation = env.reset(smiles)
	## training loop:
	for i_episode in list_episode:
		observation = env.reset(smiles)
		action = agent.agent_start(observation)
		observation, reward, done, info = env.step(action)
		while not done:
			action = agent.agent_step(reward, observation)
			observation, reward, done, info = env.step(action)
		agent.agent_end(reward)
		list_reward.append(reward)
		print(i_episode)

	fig = plt.figure()
	plt.plot(list_episode, list_reward)
	fig.savefig('linear_trend.png')
	### test on one example
	observation = env.reset(smiles)
	action = agent.agent_start(observation)
	observation, reward, done, info = env.step(action)
	while not done:
		action, _, _ = agent.agent_policy(observation)
		observation, reward, done, info = env.step(action)
	print(reward)
	svg = highlightFragments( env.original_mol, env.current_mol )
	print(svg,file=open('test_molecule.svg','w'))
	env.close()

def test_linearAllQagent():
	list_reward = []
	list_episode = list(range(100))

	env = RetroEnv()
	agent_info = {"num_edge_feature":4,
				"tau":0.1,
				"gamma": 1.,
				"alpha":0.01
	}
	fasta = "ARN"
	G_truth = fasta2nx(fasta)
	m = Chem.rdmolfiles.MolFromFASTA(fasta)
	smiles = Chem.MolToSmiles(m)
	agent = linearAllQagent()
	agent.agent_init(agent_info)
	observation = env.reset(smiles)
	## training loop:
	for i_episode in list_episode:
		observation = env.reset(smiles)
		action, preference = agent.agent_start(observation)
		print(preference)
		observation, reward, done, info = env.step(action)
		while not done:
			action = agent.agent_step(reward, observation)
			observation, reward, done, info = env.step(action)
		agent.agent_end(reward)
		list_reward.append(reward)
		print(i_episode)

	fig = plt.figure()
	plt.plot(list_episode, list_reward)
	fig.savefig('linearAll_trend.png')
	### test on one example
	observation = env.reset(smiles)
	action, preference = agent.agent_start(observation)
	print(preference)
	observation, reward, done, info = env.step(action)
	while not done:
		action, preference = agent.agent_policy(observation)
		print(preference)
		observation, reward, done, info = env.step(action)
	print(reward)
	svg = highlightFragments( env.original_mol, env.current_mol )
	print(svg,file=open('test_molecule.svg','w'))
	env.close()



def test_gnnQagent():
	torch.manual_seed(0)
	list_reward = []
	list_episode = list(range(10000))

	env = RetroEnv()
	agent_info = {"num_edge_feature":12,
				"tau_edge":0.01,
				"tau_termination":1,
				"gamma": 1.,
				"alpha":0.01
	}
	fasta = "ARN"
	G_truth = fasta2nx(fasta)
	m = Chem.rdmolfiles.MolFromFASTA(fasta)
	smiles = Chem.MolToSmiles(m)
	agent = gnnQagent()
	agent.agent_init(agent_info)
	## training loop:
	for i_episode in list_episode:
		observation = env.reset(smiles)
		action = agent.agent_start(observation)
		observation, reward, done, info = env.step(action)
		while not done:
			action = agent.agent_step(reward, observation)
			observation, reward, done, info = env.step(action)
		agent.agent_end(reward)
		list_reward.append(reward)
		print(i_episode)
	# plot reward trend
	fig = plt.figure()
	plt.plot(list_episode, list_reward)
	fig.savefig('gnn_trend.png')
	### test on one example
	observation = env.reset(smiles)
	action = agent.agent_start(observation)
	observation, reward, done, info = env.step(action)
	while not done:
		action, _, _ = agent.agent_policy(observation)
		observation, reward, done, info = env.step(action)
	print(reward)
	svg = highlightFragments( env.original_mol, env.current_mol )
	print(svg,file=open('test_molecule.svg','w'))
	env.close()




def test_motif_agent():
	list_reward = []
	list_episode = list(range(1000))

	env = RetroEnv()
	agent_info = {"num_edge_feature":12,
				"tau_edge":0.1,
				"tau_termination":0.1,
				"gamma": 1.,
				"alpha":0.01
	}
	fasta = "ARN"
	G_truth = fasta2nx(fasta)
	m = Chem.rdmolfiles.MolFromFASTA(fasta)
	smiles = Chem.MolToSmiles(m)
	agent = motif_agent()
	#observation = env.reset(smiles)
	#rdkit.Chem.Draw.MolToFile(env.original_mol, 'ARN.png', size=(500, 500))
	## training loop:
	for i_episode in list_episode:
		observation = env.reset(smiles)
		action = agent.baseline_policy(observation)
		observation, reward, done, info = env.step(action)
		while not done:
			action = agent.baseline_policy(observation)
			observation, reward, done, info = env.step(action)
		list_reward.append(reward)
		print(i_episode)
	fig = plt.figure()
	plt.plot(list_episode, list_reward)
	fig.savefig('motif_trend.png')
	


if __name__ == "__main__":
	#test_gnnQagent()
	#test_linearQagent()
	test_linearAllQagent()
	#test_motif_agent()
	






